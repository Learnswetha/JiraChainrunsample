package Jira_Assignment;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseforJira {
		public static RequestSpecification inputRequest;
		public static Response response;
		public static String id;
	
		@BeforeMethod
		public void setUp() {
			
		//Specify the end point

		RestAssured.baseURI="https://krishswetha040821.atlassian.net/rest/api/2/";

		//Authentication

		RestAssured.authentication=RestAssured.preemptive().basic("krishswetha040821@gmail.com", "ATATT3xFfGF0ArmKlf9EqWVESKiSMR48HJVstXiA2E6HPnoNc6uzoJCS8XqCg6sWX_ShpBm5mn3W0sG8zXP0MYCwSTUX-wBXQNkxmtkJxpqLnHgAeeHikRE841ANxxI9JQXuWxSEE4vKY7NEFZfMKVLSTE0n372vl9vsa_foSEu1qLnE7t2pv6Q=226B0807");
	}
	

}

