package Week3day2;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Createchangerequest {
	 @Test
		public void changerequest(){
			//Enter the End point
			RestAssured.baseURI="https://dev116510.service-now.com/api/now/table/";
			
			//Give Authorization
			RestAssured.authentication=RestAssured.basic("admin", "Ngpe$1UnA9=A");
			
			// Send via body using File
			File file=new File("./data/Createchangerequest.json");
		RequestSpecification inputRequest=RestAssured.given().contentType("application/json").when().body(file);
			
			//Send the Request
		Response response= inputRequest.post("change_request");
		String Sys_id=response.jsonPath().get("result.sys_id");
		System.out.println(Sys_id);
		response.prettyPrint();
		}
			

}
