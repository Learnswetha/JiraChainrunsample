package Week3day2;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Deletechangerequest {
	 @Test
		public void changerequest(){
			//Enter the End point
			RestAssured.baseURI="https://dev116510.service-now.com/api/now/table/";
			
			//Give Authorization
			RestAssured.authentication=RestAssured.basic("admin", "Ngpe$1UnA9=A");
			//inputRequest
			RequestSpecification inputRequest= RestAssured.given();
			Response response=inputRequest.delete("change_request/302a2ad59729611052ba322e6253afe2");
			//Extract Statusline
			String Statusline=response.getStatusLine();
			System.out.println(Statusline);
			response.prettyPrint();

}
}
