package Week3day2;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllincident {
	@Test
	public void Getallincidents() {
		
		//Enter URL
		RestAssured.baseURI="https://dev116510.service-now.com/api/now/table/";
		//Authentication
		RestAssured.authentication=RestAssured.basic("admin", "Ngpe$1UnA9=A");
		//Request body
		RequestSpecification inputRequest= RestAssured.given().queryParam("sysparm_fields", "sys_id,number,sys_update_by");
		Map<String,String> queryParams= new HashMap<String, String>();
		
		queryParams.put("sysparm_fields", "sys_id,number,sys_update_by");
		queryParams.put("sysparm_limit","1");
	
		Response response=inputRequest.get("incident");
		//Extract Statuscode
		int Statuscode=  response.getStatusCode();
		System.out.println(Statuscode);
		//Extract Statusline
		String Statusline=response.getStatusLine();
		System.out.println(Statusline);
		
		
		
		
		
	}

}
